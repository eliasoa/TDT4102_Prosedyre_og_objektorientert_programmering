#include <iostream>
#include <cassert>
#include <random>

// Problem 1
#include "problem1.hpp"
// Problem 2, 4 and 5
#include "Matrix.hpp"
// Problem 3
#include "Dummy.hpp"